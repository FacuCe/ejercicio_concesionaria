public class Moto extends Vehiculo{
    private String cilindrada;


    public Moto(String marca, String modelo, String precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    public String getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(String cilindrada) {
        this.cilindrada = cilindrada;
    }

    public void mostrarDatos() {
        System.out.println("Marca: " + this.getMarca() + " // Modelo: " + this.getModelo() + " // Cilindrada: "
                + this.getCilindrada() + " // Precio: " + this.getPrecio());
    }
}
