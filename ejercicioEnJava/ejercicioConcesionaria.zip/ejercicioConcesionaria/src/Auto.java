public class Auto extends Vehiculo {
    private int puertas;


    public Auto(String marca, String modelo, String precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public void mostrarDatos() {
        System.out.println("Marca: " + this.getMarca() + " // Modelo: " + this.getModelo() + " // Puertas: "
                + this.getPuertas() + " // Precio: " + this.getPrecio());
    }
}
