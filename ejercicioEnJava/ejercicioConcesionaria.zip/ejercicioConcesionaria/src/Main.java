import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = new ArrayList<>();

        vehiculos.add(new Auto("Peugeot", "206", "$200.000,00", 4));
        vehiculos.add(new Moto("Honda", "Titan", "$60.000,00", "125cc"));
        vehiculos.add(new Auto("Peugeot", "208", "$250.000,00", 5));
        vehiculos.add(new Moto("Yamaha", "YBR", "$80.500,50", "160cc"));

        for (Vehiculo vehiculo : vehiculos) {
            vehiculo.mostrarDatos();
        }

        System.out.println("=============================");

        Vehiculo masCaro = vehiculos.get(0);
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPrecioNumerico() > masCaro.getPrecioNumerico()) {
                masCaro = vehiculo;
            }
        }
        System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());

        Vehiculo masBarato= vehiculos.get(0);
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPrecioNumerico() < masBarato.getPrecioNumerico()) {
                masBarato = vehiculo;
            }
        }
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());

        for (Vehiculo vehiculo : vehiculos) {
            int indiceDeLaCadena = vehiculo.getModelo().indexOf("Y");
            if (indiceDeLaCadena != -1) {
                System.out.println("Vehículo que contiene en el modelo la letra 'Y': " + vehiculo.getMarca() + " "
                        + vehiculo.getModelo() + " " + vehiculo.getPrecio());
            }
        }

        System.out.println("=============================");
        System.out.println("Vehículos ordenados por precio de mayor a menor");

        boolean fin = false;
        while (fin == false) {
            fin = true;
            for (int i = 0; i < vehiculos.size() - 1; i++) {
                if (vehiculos.get(i).getPrecioNumerico() < vehiculos.get(i+1).getPrecioNumerico()) {
                    Vehiculo aux = vehiculos.get(i + 1);
                    vehiculos.set(i+1, vehiculos.get(i));
                    vehiculos.set(i, aux);
                    fin = false;
                }
            }
        }
        for (Vehiculo vehiculo : vehiculos) {
            System.out.println(vehiculo.getMarca() + " " + vehiculo.getModelo());
        }
    }
}